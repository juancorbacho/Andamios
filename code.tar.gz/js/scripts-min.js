"use strict";!function(){var e=[93,95,88,0,55,91];console.log("You failed "+e.filter(function(e){return e<70}).length+" times.")}();var test="Este es el segundo archivo";
//# sourceMappingURL=scripts-min.js.map
